### Maak de opdrachten voor deze les
{: .text-green-200 .fs-6 }

1. [Start](1Start)
2. [Cookie Clicker](2CookieClicker)
3. [Score](3Score)
4. [State](4State)

