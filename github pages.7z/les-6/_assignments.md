### Maak de opdrachten voor deze les
{: .text-green-200 .fs-6 }

1. [Start](1onderwerp)
2. [Navigatie](2navbar)
3. [Router](3router)
