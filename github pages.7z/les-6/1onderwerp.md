---
has_toc: false
nav_exclude: true
layout: default
---

# SPA en routing
Single Page Application zijn websites die voornamelijk bestaan uit een enkele pagina. React is van origine bedoelt om UIs te maken voor Single Page Applicaties.

## Leerdoelen
* Gebruik maken van Routing voor meer pagina's.
* Een navigatiebar gebruiken.

[Volgend hoofdstuk: Navigatie bar maken](../2navbar)