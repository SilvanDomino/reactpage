### Maak de opdrachten voor deze les
{: .text-green-200 .fs-6 }

1. [Start](1onderwerp)
2. [React project aanmaken](2component)
3. [Props](3props)
4. [Arrays en map](4arrays)