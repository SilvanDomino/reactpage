---
has_toc: false
nav_exclude: true
layout: default
---

De komende 6 lessen gaan we werken aan een website met 5 verschillende componenten.
* About Me
* Top 10
* Cookie Clicker
* Pokemon
* Navbar