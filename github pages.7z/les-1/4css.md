---
has_toc: false
nav_exclude: true
layout: default
---

# CSS

CSS Werkt het zelfde in (gewoon) HTML. Wat wel misschien anders is, is dat er vaak verschillende CSS bestanden worden gebruikt. Meestal krijgt ieder component een eigen CSS bestand.

De CSS bestanden die we nu hebben zijn:
* index.css
* App.css

**Index.css** wordt gebruikt voor de stijl die van toepassing is voor de hele applicatie. 
**App.css** wordt gebruikt voor de stijl die van toepassing is op alleen het *app* component. 

---

Dit is het einde van de eerste les. Voglende les gaan we componenten maken en werken met modulaire css.