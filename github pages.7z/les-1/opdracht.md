---
nav_exclude: true
---
# Opdracht
Vorig hoofdstuk heb je een artikel gemaakt. Ga dit artikel netjes stylen.
* Alle elementen moeten onder elkaar
* Het artikel moet op het midden van het scherm staan.
* Padding tussen de onderdelen (img, h1, p). 
* Achtergrond kleur

Zet deze opdracht op Github en lever de link in via Simulize.

