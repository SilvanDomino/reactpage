### Maak de opdrachten voor deze les
{: .text-green-200 .fs-6 }

1. [Start](1onderwerp)
2. [Fetch](2fetch)
3. [Rerender](3rerender)
4. [Types](4types)
