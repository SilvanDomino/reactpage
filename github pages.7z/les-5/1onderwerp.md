---
has_toc: false
nav_exclude: true
layout: default
---

# Fetch en State
We hebben nu gekeken hoe een state werkt. Deze les gaan we een fetchen naar een API om informatie op te halen. We beginnen met gewoon fetchen, en we gaan daarna zien waarom het ook hierbij belangrijk is om een fetch te gebruiken.

## Maken van component
Maak twee bestanden aan, `Pokemon.jsx` en `Pokemon.module.css`. Begin met het maken van een component genaamd Pokemon. 
